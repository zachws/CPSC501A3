package cpsc501a3;

public class Main {
    public static void main(String[] args) {
        //System.out.println("Hello world!");
        ObjectCreator testCreator = new ObjectCreator();
        testCreator.createObjectFromChoice();
    }
}