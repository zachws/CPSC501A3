package cpsc501a3;

public class PrimitiveObject{

    public int intVar; 
    public float floatVar; 
    public double doubleVar; 
    public char charVar = 'a';
    public boolean boolVar;

}