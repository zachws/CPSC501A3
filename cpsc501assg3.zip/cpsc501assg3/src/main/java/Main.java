import cpsc501a3.ObjectCreator;

public class Main {
    public static void main(String[] args) {
        //System.out.println("Hello world!");
        ObjectCreator testCreator = new ObjectCreator();
        char choice = '1'; 
        testCreator.createObject(choice);
    }
}